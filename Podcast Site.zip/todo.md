# Intelligent Theft Website TODO

## Features to Implement

- [x] Database schema for early access signups (email, timestamp)
- [x] Backend tRPC procedure for signup submission
- [x] Hero section with "Steal What Works" messaging
- [x] Early access email capture form
- [x] Brand styling (black background, white text, deep blue accents)
- [x] Success/error toast notifications for signup
- [x] Responsive design for mobile/desktop

## Bugs

(None yet)

## New Changes

- [x] Update hero section copy to be audience-focused (not host-focused)
