import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

export default function Home() {
  const [email, setEmail] = useState("");
  const signupMutation = trpc.signup.submit.useMutation({
    onSuccess: (data) => {
      toast.success(data.message);
      setEmail("");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      toast.error("Please enter your email");
      return;
    }
    signupMutation.mutate({ email: email.trim() });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Hero Section */}
      <section className="container flex flex-col items-center justify-center min-h-screen px-4 py-20">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          {/* Title */}
          <h1 className="text-7xl md:text-9xl font-black uppercase tracking-tight leading-none">
            INTELLIGENT
            <br />
            THEFT
          </h1>

          {/* Subtitle */}
          <p className="text-2xl md:text-3xl font-bold text-muted-foreground uppercase tracking-wide">
            The Podcast
          </p>

          {/* Tagline */}
          <div className="space-y-4 pt-8">
            <p className="text-3xl md:text-5xl font-bold leading-tight">
              Steal What Works.
              <br />
              Build What Matters.
            </p>
          </div>

          {/* Description */}
          <div className="max-w-2xl mx-auto space-y-4 pt-8">
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Watch operators tear down strategies, build workflows live, and give away what's actually working.
            </p>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              No script. No theory. Just real tactics you can steal today.
            </p>
          </div>

          {/* Early Access Form */}
          <div className="pt-12">
            <div className="max-w-md mx-auto space-y-4">
              <p className="text-sm uppercase tracking-wider text-primary font-bold">
                Get Early Access
              </p>
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
                <Input
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1 bg-input border-border text-foreground placeholder:text-muted-foreground h-12 text-base"
                  disabled={signupMutation.isPending}
                />
                <Button
                  type="submit"
                  size="lg"
                  className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold uppercase tracking-wide h-12 px-8"
                  disabled={signupMutation.isPending}
                >
                  {signupMutation.isPending ? "Submitting..." : "Steal Access"}
                </Button>
              </form>
              <p className="text-xs text-muted-foreground">
                We'll notify you when we launch. No spam, no BS.
              </p>
            </div>
          </div>

          {/* Footer Tagline */}
          <div className="pt-16">
            <p className="text-sm text-muted-foreground uppercase tracking-widest">
              The best operators don't invent. They steal.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
